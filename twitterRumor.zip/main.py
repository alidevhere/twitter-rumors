import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from keras.models import Sequential
from keras.layers import Dense,SimpleRNN,LSTM
from keras.utils import to_categorical
from sklearn.preprocessing import MinMaxScaler

if __name__ == '__main__':


    # reading files

    events = ["charliehebdo", "ferguson", "germanwings-crash", "gurlitt", "ottawashooting", "putinmissing",
              "sydneysiege"]
    charlie = pd.read_csv('CSV_Files/charliehebdo.csv', names=['timeDiff', 'status', 'Freq'], header=0)
    ferguson = pd.read_csv('CSV_Files/ferguson.csv',names=['timeDiff', 'status', 'Freq'], header=0)
    germanwings = pd.read_csv('CSV_Files/germanwings-crash.csv',names=['timeDiff', 'status', 'Freq'], header=0)
    gurlitt = pd.read_csv('CSV_Files/gurlitt.csv',names=['timeDiff', 'status', 'Freq'], header=0)
    ottawashooting = pd.read_csv('CSV_Files/ottawashooting.csv',names=['timeDiff', 'status', 'Freq'], header=0)
    putinmissing = pd.read_csv('CSV_Files/putinmissing.csv',names=['timeDiff', 'status', 'Freq'], header=0)
    sydneysiege = pd.read_csv('CSV_Files/sydneysiege.csv',names=['timeDiff', 'status', 'Freq'], header=0)

    # splitting dataset into train and test
    testing = charlie
    training = pd.concat([ferguson, germanwings, ottawashooting, putinmissing, sydneysiege],ignore_index=True)
    #print(training)


    #preparing training data
    x_train = training[['timeDiff','Freq']]
    scaler =  MinMaxScaler(feature_range=(0,1))
    x_train = scaler.fit_transform(x_train)
    y_train = to_categorical(training[['status']], num_classes=2)

    print(x_train)
    print(y_train)

    # preparing testing data
    x_test = testing[['timeDiff', 'Freq']]
    scaler = MinMaxScaler(feature_range=(0, 1))
    x_test = scaler.fit_transform(x_test)
    y_test = to_categorical(testing[['status']], num_classes=2)

    print(x_test.shape)
    print(y_test.shape)

    # define model

    # Simple RNN_1
    # difficulties == Time Steps,learning rate,
    # reshaping data for SimpleRNN_1 model
    x_train_RNN = x_train.reshape(x_train.shape[0], x_train.shape[1], 1)
    x_test_RNN = x_test.reshape(x_test.shape[0], x_test.shape[1], 1)
    print(x_train_RNN.shape)


    # RNN_1 MODEL
    hidden_layer_units = int((len(x_train_RNN)+2)/2)
    print(hidden_layer_units)
    RNN_1 = Sequential()
    RNN_1.add(SimpleRNN(units=2, input_shape=(2, 1)))  # ,input_shap
    RNN_1.add(Dense(hidden_layer_units,activation='sigmoid'))
    RNN_1.compile(optimizer='adam', loss='categorical_crossentropy') #, metrics=['binary_accuracy']
    print(RNN_1.summary())

    # i think y_train is same for all
    RNN_1.fit(x_train_RNN, y_train, epochs=300, batch_size=32, input_shape=(2,1))

    print("Evaluate on test data")
    results = RNN_1.evaluate(x_test_RNN, y_test, verbose=1)
    print("test loss, test acc:", results)

    prediction = RNN_1.predict(x_test_RNN)
    print('Prediction Accuracy = ', prediction)
